import { Router } from 'express';
import *  as AlbumsController from './albums.controller';
const router = Router();
router.
route('/books').
get(AlbumsController.readAlbums);

router.
route('/books/:authors').
get(AlbumsController.readAlbumsByArtist);

router.
route('/books/search/authors/:search').
get(AlbumsController.readAlbumsByArtistSearch);

router.
route('/books/search/description/:search').
get (AlbumsController.readAlbumsByDescriptionSearch);

router.
route('/books').
post (AlbumsController.createAlbum);

router.
route('/books').
put (AlbumsController.updateAlbum);
router.

route('/books/:albumid').
delete (AlbumsController.deleteAlbum);
export default router;