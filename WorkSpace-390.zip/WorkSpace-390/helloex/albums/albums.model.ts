
import { Track } from '../tracks/tracks.model';

export interface Album {
albumId: number,
title: string,
artist: string,
year: string,
description: string,
image: string,
tracks: Track[]
 }