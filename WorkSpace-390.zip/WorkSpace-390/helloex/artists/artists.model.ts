export interface Artist{
    artist: string;
}